function operar(operacion) {
    let n1 = document.getElementById("num1").value;
    let n2 = document.getElementById("num2").value;
    let resultado = document.getElementById("resultado");

    // Validación: campos vacíos
    if (n1.trim() === "" || n2.trim() === "") {
        resultado.textContent = "⚠️ Ambos campos deben tener un número.";
        return;
    }

    // Validación: solo números
    if (isNaN(n1) || isNaN(n2)) {
        resultado.textContent = "⚠️ Solo puedes ingresar números.";
        return;
    }

    // Convertir a número
    n1 = Number(n1);
    n2 = Number(n2);

    // Validación: no ceros
    if (n1 === 0 || n2 === 0) {
        resultado.textContent = "⚠️ No se permiten ceros.";
        return;
    }

    let res;

    switch (operacion) {
        case '+':
            res = n1 + n2;
            break;

        case '-':
            res = n1 - n2;
            break;

        case '*':
            res = n1 * n2;
            break;

        case '/':
            if (n2 === 0) {
                resultado.textContent = "⚠️ No se puede dividir entre 0.";
                return;
            }
            res = n1 / n2;
            break;
    }

    resultado.textContent = "Resultado: " + res;
}
